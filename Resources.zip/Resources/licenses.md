#Third party softwares
###CAAnimationBlocks
Xissburg  
<http://xissburg.com>


###ColorConverter
Matteo Alessani  
<http://www.extendi.it>


###DCRoundSwitch
Patrick Richards  
<http://domesticcat.com.au>  
_MIT license_


###DTFoundation
Oliver Drobnik  
<http://www.cocoanetics.com>  
_BSD license_


###HPGrowingTextView
Hans Pinckaers  
<http://hanspinckaers.com>  
_MIT license_


###InAppSettingsKit
Luc Vandal, Edovia Inc., Ortwin Gentz, FutureTap GmbH  
<http://www.inappsettingskit.com/>  
_BSD license_


###NinePatch
Tortuga 22, Inc.  
<http://www.tortuga22.com>  
_Apache license_


###OrderedDictionary
Matt Gallagher  
<http://cocoawithlove.com>


###TPMultiLayoutViewController
Michael Tyson  
<http://atastypixel.com>  
_MIT license_


###UACellBackgroundView
Matt Coneybeare  
<http://code.coneybeare.net>


###XMLRPC
Eric Czarny  
<http://divisiblebyzero.com/>  
_MIT license_


#Graphics
###Kerosine  
<http://www.kerosine.fr>

#Translations
###Russian
Maxim Solodovnik  
<solomax666@gmail.com>

#Utilitary softwares
###Localization Suite  
<http://www.loc-suite.org>
